package DSCoinPackage;

public class DSCoin_Malicious {

  public TransactionQueue pendingTransactions;
  public BlockChain_Malicious bChain;
  public Members[] memberlist;
  public String latestCoinID;
}
